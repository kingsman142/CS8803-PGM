function out=isoctave
out=~isempty(ver('octave'));