import sys
import numpy as np
import pickle

def get_x_vec(num):
    x_vec = np.empty(12, dtype=np.uint8)
    for i in range(12):
        x_vec[i] = 0 != (num & (1 << i))
    return x_vec

if __name__ == '__main__':
    px = np.zeros(4096)
    with open(sys.argv[1], 'r') as file:
        for line in file:
            num, prob = line.split('\t')
            num = int(num)
            prob = float(prob)
            px[num] = prob
            

    px0_emp, pxi_x0_emp, pxi_x1_4_emp = pickle.load(open('p8c_data.pkl', 'rb'))
    px_emp = np.zeros_like(px)
    for num in range(4096):
        x = get_x_vec(num)
        temp = px0_emp[x[0]]
        for i in range(4):
            temp *= pxi_x0_emp[i, x[0], x[i+1]]
        for i in range(7):
            temp *= pxi_x1_4_emp[i, x[1], x[2], x[3], x[4], x[i+5]]
        px_emp[num] = temp

    l1_dist = np.sum(np.abs(px - px_emp))
    print('L1:', l1_dist)



