import sys
import numpy as np
import pickle

DO_READ = True

def get_x_vec(num):
    x_vec = np.empty(12, dtype=np.uint8)
    for i in range(12):
        x_vec[i] = 0 != (num & (1 << i))
    return x_vec

if __name__ == '__main__':
    # dim0: x0
    px0 = np.zeros(2)
    # dim0: i
    # dim1: x0
    # dim2: xi
    pxi_x0 = np.zeros((4, 2, 2))
    # dim0: i
    # dim1-4: x1-4
    # dim5: xi
    pxi_x1_4 = np.zeros((7, 2, 2, 2, 2, 2))

    if DO_READ:
        with open(sys.argv[1], 'r') as file:
            for n, line in enumerate(file):
#                if 100 == n:
#                    break
                if 0 == (n % 40000):
                    print('{}% complete'.format(100 * n / 4000000))
                x = get_x_vec(int(line))
                px0[x[0]] += 1
                for i in range(4):
                    pxi_x0[i, x[0], x[i+1]] += 1
                for i in range(7):
                    pxi_x1_4[i, x[1], x[2], x[3], x[4], x[i+5]] += 1
        px0 /= np.sum(px0, axis=-1, keepdims=True)
        pxi_x0 /= np.sum(pxi_x0, axis=-1, keepdims=True)
        pxi_x1_4 /= np.sum(pxi_x1_4, axis=-1, keepdims=True)
        pickle.dump((px0, pxi_x0, pxi_x1_4), open('p8c_data.pkl', 'wb'))

    px0, pxi_x0, pxi_x1_4 = pickle.load(open('p8c_data.pkl', 'rb'))

    px0 = np.round(px0, 4)
    pxi_x0 = np.round(pxi_x0, 4)
    pxi_x1_4 = np.round(pxi_x1_4, 4)

    print(r'\begin{tabular}{c|cc}')
    print('    $P(X_0)$ & $X_0 = 0$ & $X_0 = 1$ \\\\')
    print('    \\hline')
    print('    & {} & {} \\\\'.format(px0[0], px0[1]))
    print(r'\end{tabular}')
    print(r'\\ \\')

    for i in range(4):
        print(r'\begin{tabular}{c|cc}')
        print('    $P(X_{} | X_0)$ & $X_{} = 0$ & $X_{} = 1$ \\\\'.format(i+1, i+1, i+1))
        print('    \\hline')
        for i0 in range(2):
            for ii in range(2):
                print('    $X_0 = {}$ & {} & {} \\\\'.format(i0, pxi_x0[i, i0, 0], pxi_x0[i, i0, 1]))
        print(r'\end{tabular}')
        print(r'\\ \\')

    for i in range(7):
        print(r'\begin{tabular}{c|cc}')
        print('    $P(X_{{{}}} | X_1, X_2, X_3, X_4)$ & $X_{{{}}} = 0$ & $X_{{{}}} = 1$ \\\\'.format(i+5, i+5, i+5))
        print('    \\hline')
        for i1 in range(2):
            for i2 in range(2):
                for i3 in range(2):
                    for i4 in range(2):
                        print('    $X_1 = {}, X_2 = {}, X_3 = {}, X_4 = {}$ & {} & {} \\\\'.format(i1, i2, i3, i4, pxi_x1_4[i, i1, i2, i3, i4, 0], pxi_x1_4[i, i1, i2, i3, i4, 1]))
        print(r'\end{tabular}')
        print(r'\\ \\')



