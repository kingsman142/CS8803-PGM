function v=nonzerovalue(x)
v=full(x(x~=0));