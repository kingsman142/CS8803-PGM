function [newpot maxstate]=max(pot,variables)
%MAX Maximise a const 
% simply returns the same potential, with maxstate empty
newpot=pot; maxstate=[];